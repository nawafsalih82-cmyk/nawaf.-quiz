# Nawaf Past Simple Quiz V4

Android quiz app for Simple Past verbs.

Features:
- 10 questions, 3 choices each.
- 30-second timer per question.
- Correct/wrong feedback with sounds.
- Large text controls from 16 to 72.
- Font family selection.
- Font color selection.
- Six visual themes including navy/gold.
- Settings are saved on the device.
- Large bold credit: تصميم الأستاذ نواف المتيوتي
- Android 10+ (minSdk 29).
