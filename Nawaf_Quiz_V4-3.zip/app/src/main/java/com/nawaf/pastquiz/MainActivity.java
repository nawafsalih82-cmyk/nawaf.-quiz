package com.nawaf.pastquiz;

import android.app.Activity;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.graphics.*;
import android.view.*;
import android.content.*;
import android.media.MediaPlayer;
import java.util.*;

public class MainActivity extends Activity {
    QuizView quizView;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        quizView = new QuizView(this);
        applyBars();
        setContentView(quizView);
    }
    void applyBars(){
        int[] t=quizView==null?new int[]{4,20,55}:quizView.themeColors();
        getWindow().setStatusBarColor(t[0]);
        getWindow().setNavigationBarColor(t[1]);
    }
    @Override protected void onDestroy() {
        if (quizView != null) quizView.stopTimer();
        super.onDestroy();
    }

    static class Q { String verb; String[] options; int correct; Q(String v,String[] o,int c){verb=v;options=o;correct=c;} }

    class QuizView extends View {
        Paint p=new Paint(Paint.ANTI_ALIAS_FLAG), stroke=new Paint(Paint.ANTI_ALIAS_FLAG);
        ArrayList<Q> qs=new ArrayList<>();
        int index=0,score=0,selected=-1; long timeLeft=30000; CountDownTimer timer;
        boolean locked=false,finished=false,settings=false;
        int feedbackColor=Color.TRANSPARENT; String feedbackText="";
        android.content.SharedPreferences prefs;
        int themeIndex,fontColorIndex,fontIndex; float userFontSize;
        final int[][] themes={
            {Color.rgb(4,20,55),Color.rgb(2,10,28),Color.rgb(18,78,150),Color.rgb(236,190,55)},
            {Color.rgb(22,15,7),Color.rgb(8,5,2),Color.rgb(118,67,14),Color.rgb(242,196,73)},
            {Color.rgb(7,43,31),Color.rgb(2,20,14),Color.rgb(15,105,75),Color.rgb(230,199,76)},
            {Color.rgb(52,10,24),Color.rgb(25,4,12),Color.rgb(132,28,62),Color.rgb(255,194,73)},
            {Color.rgb(35,12,66),Color.rgb(16,5,31),Color.rgb(91,45,155),Color.rgb(221,183,255)},
            {Color.rgb(18,18,20),Color.rgb(5,5,6),Color.rgb(65,65,72),Color.rgb(235,235,235)}
        };
        final int[] textColors={Color.WHITE,Color.rgb(255,225,110),Color.rgb(180,235,255),Color.rgb(255,170,190),Color.rgb(215,190,255),Color.rgb(180,255,200)};
        final String[] fontNames={"Sans","Serif","Monospace","Condensed"};
        final String[] fontFamilies={"sans-serif","serif","monospace","sans-serif-condensed"};
        final int green=Color.rgb(28,155,79),red=Color.rgb(198,45,55);

        QuizView(Context c){
            super(c); setFocusable(true);
            prefs=getSharedPreferences("quiz_settings",MODE_PRIVATE);
            themeIndex=prefs.getInt("theme",0); fontColorIndex=prefs.getInt("fontColor",0); fontIndex=prefs.getInt("font",0); userFontSize=prefs.getFloat("fontSize",30f);
            qs.add(new Q("go",new String[]{"goes","went","going"},1));
            qs.add(new Q("do",new String[]{"does","doing","did"},2));
            qs.add(new Q("see",new String[]{"saw","seen","seed"},0));
            qs.add(new Q("write",new String[]{"writing","written","wrote"},2));
            qs.add(new Q("is",new String[]{"ised","was","ising"},1));
            qs.add(new Q("drink",new String[]{"drank","drunk","drinking"},0));
            qs.add(new Q("eat",new String[]{"eating","ate","ote"},1));
            qs.add(new Q("sleep",new String[]{"slept","sleeping","seelped"},0));
            qs.add(new Q("find",new String[]{"found","finded","finding"},0));
            qs.add(new Q("have",new String[]{"had","has","having"},0));
            startTimer();
        }
        int[] themeColors(){return themes[themeIndex];}
        void save(){prefs.edit().putInt("theme",themeIndex).putInt("fontColor",fontColorIndex).putInt("font",fontIndex).putFloat("fontSize",userFontSize).apply(); applyBars();}
        void stopTimer(){if(timer!=null)timer.cancel();}
        void startTimer(){stopTimer();timeLeft=30000;timer=new CountDownTimer(30000,1000){public void onTick(long ms){timeLeft=ms;invalidate();}public void onFinish(){timeLeft=0;if(!locked&&!finished)timeout();}}.start();}
        void timeout(){locked=true;feedbackColor=red;feedbackText="انتهى الوقت!";playSound("wrong");invalidate();postDelayed(new Runnable(){ @Override public void run(){ nextQuestion(); } },1100);}
        void nextQuestion(){if(index>=qs.size()-1){finished=true;stopTimer();invalidate();return;}index++;selected=-1;locked=false;feedbackColor=Color.TRANSPARENT;feedbackText="";startTimer();invalidate();}
        void answer(int i){if(locked||finished)return;locked=true;selected=i;Q q=qs.get(index);if(i==q.correct){score++;feedbackColor=green;feedbackText="أحسنت! إجابة صحيحة 👏";playSound("applause");}else{feedbackColor=red;feedbackText="للأسف، الإجابة الصحيحة: "+q.options[q.correct];playSound("wrong");}stopTimer();invalidate();postDelayed(new Runnable(){ @Override public void run(){ nextQuestion(); } },1100);}
        void restart(){index=0;score=0;selected=-1;locked=false;finished=false;feedbackColor=Color.TRANSPARENT;feedbackText="";settings=false;startTimer();invalidate();}
        void playSound(String name){try{int id=getResources().getIdentifier(name,"raw",getPackageName());if(id==0)return;MediaPlayer mp=MediaPlayer.create(MainActivity.this,id);if(mp!=null){mp.setOnCompletionListener(new MediaPlayer.OnCompletionListener(){ @Override public void onCompletion(MediaPlayer player){ player.release(); }});mp.start();}}catch(Exception ignored){}}
        String family(){return fontFamilies[fontIndex];}
        void text(Canvas c,String s,float x,float y,float size,int color,boolean bold,Paint.Align a){p.setStyle(Paint.Style.FILL);p.setShader(null);p.setColor(color);p.setTextSize(size);p.setTextAlign(a);p.setTypeface(Typeface.create(family(),bold?Typeface.BOLD:Typeface.NORMAL));c.drawText(s,x,y,p);}
        float fit(String s,float max,float avail){p.setTypeface(Typeface.create(family(),Typeface.BOLD));p.setTextSize(max);while(p.measureText(s)>avail&&max>18){max-=1;}return max;}
        void round(Canvas c,float l,float t,float r,float b,float rad,int color){p.setStyle(Paint.Style.FILL);p.setShader(null);p.setColor(color);c.drawRoundRect(l,t,r,b,rad,rad,p);}
        void border(Canvas c,float l,float t,float r,float b,float rad,int color,float width){stroke.setStyle(Paint.Style.STROKE);stroke.setStrokeWidth(width);stroke.setColor(color);c.drawRoundRect(l,t,r,b,rad,rad,stroke);}
        int tc(){return textColors[fontColorIndex];}

        @Override protected void onDraw(Canvas c){
            int w=getWidth(),h=getHeight(); int[] th=themes[themeIndex];
            c.drawColor(th[0]); p.setShader(new LinearGradient(0,0,0,h,th[2],th[0],Shader.TileMode.CLAMP));c.drawRect(0,0,w,h,p);p.setShader(null);
            p.setShader(new LinearGradient(0,0,w,0,th[3],Color.WHITE,th[3],Shader.TileMode.CLAMP));c.drawRect(0,0,w,8,p);p.setShader(null);
            if(settings){drawSettings(c,w,h);return;}
            drawGame(c,w,h,th);
        }
        void drawGame(Canvas c,int w,int h,int[] th){
            int fg=tc(); text(c,"نواف صالح",w-22,43,20,fg,true,Paint.Align.RIGHT);
            text(c,"اختبار الماضي البسيط",w/2f,78,27,th[3],true,Paint.Align.CENTER);
            text(c,"Past Simple",w/2f,105,16,Color.WHITE,false,Paint.Align.CENTER);
            text(c,"تصميم الأستاذ نواف المتيوتي",w/2f,140,Math.max(30,userFontSize+4),th[3],true,Paint.Align.CENTER);
            round(c,18,155,w-18,205,18,Color.argb(70,255,255,255));border(c,18,155,w-18,205,18,th[3],2);
            text(c,"⚙ الإعدادات",w/2f,189,20,fg,true,Paint.Align.CENTER);
            if(finished){drawResult(c,w,h,th);return;}
            text(c,"السؤال "+(index+1)+" من "+qs.size(),w-24,235,20,fg,true,Paint.Align.RIGHT);
            text(c,"النتيجة: "+score,w/2f,235,20,th[3],true,Paint.Align.CENTER);
            float frac=timeLeft/30000f;round(c,24,250,w-24,268,9,Color.rgb(20,43,78));round(c,24,250,24+(w-48)*frac,268,9,frac<.25?red:th[3]);
            text(c,String.format(Locale.US,"%02d",(int)Math.ceil(timeLeft/1000.0)),w/2f,310,42,frac<.25?red:th[3],true,Paint.Align.CENTER);
            text(c,"ثانية",w/2f,335,16,fg,false,Paint.Align.CENTER);
            round(c,18,355,w-18,540,25,Color.argb(95,0,0,0));border(c,18,355,w-18,540,25,th[3],3);
            text(c,"ما هو تصريف الفعل في الماضي البسيط؟",w/2f,397,fit("ما هو تصريف الفعل في الماضي البسيط؟",Math.min(34,userFontSize),w-55),fg,true,Paint.Align.CENTER);
            text(c,qs.get(index).verb,w/2f,465,fit(qs.get(index).verb,Math.min(72,userFontSize+22),w-55),th[3],true,Paint.Align.CENTER);
            text(c,"Past Simple",w/2f,510,17,Color.rgb(190,210,235),false,Paint.Align.CENTER);
            String[] letters={"A","B","C"}; Q q=qs.get(index);
            for(int i=0;i<3;i++){float top=565+i*88;int bg=Color.argb(125,15,65,135);int bc=th[3];if(locked&&selected==i){bg=(i==q.correct)?green:red;bc=Color.WHITE;}else if(locked&&i==q.correct){bg=Color.rgb(20,104,68);bc=th[3];}round(c,18,top,w-18,top+70,22,bg);border(c,18,top,w-18,top+70,22,bc,2);text(c,letters[i],54,top+46,25,th[3],true,Paint.Align.CENTER);String opt=q.options[i];text(c,opt,w-55,top+46,fit(opt,Math.min(72,userFontSize),w-125),fg,true,Paint.Align.RIGHT);}
            if(!feedbackText.isEmpty())text(c,feedbackText,w/2f,850,21,feedbackColor,true,Paint.Align.CENTER);
            text(c,"تصميم الأستاذ نواف المتيوتي",w/2f,h-24,Math.max(30,userFontSize+4),th[3],true,Paint.Align.CENTER);
        }
        void drawResult(Canvas c,int w,int h,int[] th){
            text(c,"انتهى الاختبار",w/2f,285,40,th[3],true,Paint.Align.CENTER);text(c,"نتيجتك",w/2f,355,24,tc(),true,Paint.Align.CENTER);text(c,score+" / "+qs.size(),w/2f,455,fit(score+" / "+qs.size(),72,w-80),th[3],true,Paint.Align.CENTER);text(c,score>=9?"ممتاز جدًا! 🌟":score>=7?"أحسنت! استمر بالتدريب 👏":"حاول مرة أخرى وستتحسن 💪",w/2f,520,24,tc(),true,Paint.Align.CENTER);round(c,55,565,w-55,650,22,th[2]);border(c,55,565,w-55,650,22,th[3],3);text(c,"إعادة الاختبار",w/2f,620,25,Color.WHITE,true,Paint.Align.CENTER);text(c,"تصميم الأستاذ نواف المتيوتي",w/2f,h-55,Math.max(30,userFontSize+4),th[3],true,Paint.Align.CENTER);
        }
        void drawSettings(Canvas c,int w,int h){
            int[] th=themes[themeIndex],fg=tc(); text(c,"⚙ إعدادات البرنامج",w/2f,65,32,th[3],true,Paint.Align.CENTER);
            text(c,"حجم الخط: "+(int)userFontSize,w-28,125,24,fg,true,Paint.Align.RIGHT);
            round(c,28,145,w-28,165,10,Color.argb(80,255,255,255));float knob=28+(w-56)*((userFontSize-16f)/56f);round(c,knob-13,135,knob+13,175,13,th[3]);
            text(c,"16",28,200,17,fg,true,Paint.Align.LEFT);text(c,"72",w-28,200,17,fg,true,Paint.Align.RIGHT);
            text(c,"نوع الخط",w-28,245,24,fg,true,Paint.Align.RIGHT);
            for(int i=0;i<4;i++){float l=18+i*(w-36)/4f+5,r=18+(i+1)*(w-36)/4f-5;float t=265,b=325;round(c,l,t,r,b,18,i==fontIndex?th[2]:Color.argb(70,255,255,255));border(c,l,t,r,b,18,th[3],2);text(c,fontNames[i],(l+r)/2,t+39,17,fg,i==fontIndex,Paint.Align.CENTER);}
            text(c,"لون الخط",w-28,370,24,fg,true,Paint.Align.RIGHT);
            for(int i=0;i<6;i++){float l=24+i*(w-48)/6f+5,r=24+(i+1)*(w-48)/6f-5;float t=390,b=445;round(c,l,t,r,b,16,textColors[i]);if(i==fontColorIndex)border(c,l-2,t-2,r+2,b+2,18,Color.WHITE,4);}
            text(c,"الثيم",w-28,495,24,fg,true,Paint.Align.RIGHT);
            String[] tn={"أزرق","ذهبي","أخضر","أحمر","بنفسجي","أسود"};
            for(int i=0;i<6;i++){float l=18+(i%3)*(w-36)/3f+5;float r=18+(i%3+1)*(w-36)/3f-5;float t=515+(i/3)*72,b=t+58;round(c,l,t,r,b,18,themes[i][2]);border(c,l,t,r,b,18,i==themeIndex?themes[i][3]:Color.argb(100,255,255,255),i==themeIndex?3:1);text(c,tn[i],(l+r)/2,t+38,17,Color.WHITE,i==themeIndex,Paint.Align.CENTER);}
            round(c,45,675,w-45,745,20,Color.argb(90,255,255,255));border(c,45,675,w-45,745,20,th[3],2);text(c,"إعادة الإعدادات الافتراضية",w/2f,720,21,fg,true,Paint.Align.CENTER);
            round(c,45,765,w-45,835,20,th[2]);border(c,45,765,w-45,835,20,th[3],2);text(c,"العودة إلى الاختبار",w/2f,810,21,Color.WHITE,true,Paint.Align.CENTER);
            text(c,"تصميم الأستاذ نواف المتيوتي",w/2f,h-25,Math.max(30,userFontSize+4),th[3],true,Paint.Align.CENTER);
        }
        void defaultSettings(){themeIndex=0;fontColorIndex=0;fontIndex=0;userFontSize=30;save();invalidate();}
        @Override public boolean onTouchEvent(MotionEvent e){
            if(e.getAction()!=MotionEvent.ACTION_UP)return true;float x=e.getX(),y=e.getY();int w=getWidth();
            if(settings){
                if(y>=135&&y<=185){float ratio=Math.max(0,Math.min(1,(x-28)/(w-56f)));userFontSize=16+ratio*56;save();invalidate();return true;}
                if(y>=265&&y<=330){int i=(int)((x-18)/( (w-36f)/4f));if(i>=0&&i<4){fontIndex=i;save();invalidate();}return true;}
                if(y>=385&&y<=455){int i=(int)((x-24)/( (w-48f)/6f));if(i>=0&&i<6){fontColorIndex=i;save();invalidate();}return true;}
                if(y>=510&&y<=660){int col=(int)((x-18)/((w-36f)/3f));int row=(int)((y-510)/72);int i=row*3+col;if(i>=0&&i<6){themeIndex=i;save();invalidate();}return true;}
                if(y>=675&&y<=750){defaultSettings();return true;}
                if(y>=765&&y<=845){settings=false;invalidate();return true;}
                return true;
            }
            if(y>=150&&y<=215){settings=true;stopTimer();invalidate();return true;}
            if(finished){if(y>=550&&y<=665)restart();return true;}
            if(y>=565&&y<=635)answer(0);else if(y>=653&&y<=723)answer(1);else if(y>=741&&y<=811)answer(2);
            return true;
        }
    }
}
